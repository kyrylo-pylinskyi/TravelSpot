﻿namespace Api.Services.Helpers
{
    public interface IUserService
    {
        string GetEmail();
    }
}