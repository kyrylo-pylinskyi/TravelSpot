﻿namespace Api.Models.DTO.Response.Auth
{
    public class AuthResponse
    {
        public string Message { get; set; }
        public string UserEmail { get; set; }
    }
}
