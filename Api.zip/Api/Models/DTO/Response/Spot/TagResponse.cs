﻿namespace Api.Models.DTO.Response.Spot
{
    public class TagResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
