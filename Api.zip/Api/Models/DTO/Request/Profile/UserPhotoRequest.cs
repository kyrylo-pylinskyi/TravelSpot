﻿namespace Api.Models.DTO.Request.Profile
{
    public class UserPhotoRequest
    {
        public IFormFile? Photo { get; set; }
    }
}
