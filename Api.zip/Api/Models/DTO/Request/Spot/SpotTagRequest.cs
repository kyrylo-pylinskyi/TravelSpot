﻿namespace Api.Models.DTO.Request.Spot
{
    public class SpotTagRequest
    {
        public int SpotId { get; set; }
        public int TagId { get; set; }
    }
}
