﻿namespace Api.Models.DTO.Request.Spot
{
    public class TagRequest
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
