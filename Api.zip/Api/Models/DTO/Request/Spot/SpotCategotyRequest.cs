﻿namespace Api.Models.DTO.Request.Spot
{
    public class SpotCategotyRequest
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int SpotId { get; set; }
    }
}
