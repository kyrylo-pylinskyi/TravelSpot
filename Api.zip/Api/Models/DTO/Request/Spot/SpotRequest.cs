﻿using Api.Models.Entities;

namespace Api.Models.DTO.Request.Spot
{
    public class SpotRequest
    {
        public string SpotName { get; set; }
        public string SpotDescription { get; set; }
    }
}
